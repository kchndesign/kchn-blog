package com.kchn.blog.api.Article;

public interface ArticleRepositoryUtils {
    
}
