package com.kchn.blog.api.Article;

import org.hibernate.validator.internal.util.stereotypes.Lazy;
import org.springframework.beans.factory.annotation.Autowired;

public class ArticleRepositoryUtilsImpl implements ArticleRepositoryUtils {
    
    
}
